import Document, { Html, Head, Main, NextScript } from 'next/document';

class MyDocument extends Document {
  render() {
    return (
      <>
      <Html lang="en">
        <Head>
          <title>CCSA</title>
          <link rel="icon" type="image/x-icon" href="/images/cc.png"></link>
          <link
            rel="stylesheet"
            href="/assets/css/adminlte.min.css"
          />
          <link
            rel="stylesheet"
            href="/assets/css/all.css"
          />
          <link
            rel="stylesheet"
            href="/assets/css/OverlayScrollbars.css"
          />
          <script src="/assets/js/jquery.js"></script>
          <script src="/assets/js/adminlte.min.js"></script>
          <script src="/assets/js/jquery-ui.min.js"></script>
          <script src="/assets/js/bootstrap.bundle.min.js"></script>
        </Head>
        <body className='hold-transition sidebar-mini layout-fixed' data-panel-auto-height-mode="height">
          <Main />
          <NextScript />
        </body>
      </Html>
      </>
    );
  }
}

export default MyDocument;