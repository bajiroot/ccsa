import Table from './Table';
export default function infobaru() {
    return (
      <>
      <h3>Info Terbaru</h3>
      <Table/>
      </>
)
}
