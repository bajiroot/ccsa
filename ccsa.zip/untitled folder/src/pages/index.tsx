import React from 'react';

export default function Home() {
  return (
    <>
      <aside className="main-sidebar sidebar-dark-primary elevation-4">
        {/* Sidebar */}
        <div className="sidebar">
          <nav className="mt-2">
            <ul className="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
              <li className="nav-item">
                <a href="#" className="nav-link">
                  <i className="nav-icon fas fa-book" />
                  <p>CCSA<i className="right fas fa-angle-left"></i></p>
                </a>
                <ul className="nav nav-treeview">
                  <li className="nav-item">
                    <a href={"/components/knowledgebase/infobaru"} className="nav-link"><i className="fas fa-angle-right nav-icon"></i>Info Baru</a>
                    
                  </li>

                  <li className='nav-item'>
                    <a href="#" className="nav-link">
                      <i className="fas fa-angle-right nav-icon"></i>
                      <p>KB Nasional</p>
                    </a>
                  </li>

                  <li className='nav-item'>
                    <a href="#" className="nav-link">
                      <i className="fas fa-angle-right nav-icon"></i>
                      <p>Prosentase Baca</p>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
            <ul className='nav-item'>

            </ul>
          </nav>
        </div>
      </aside>


        <div className="content-wrapper iframe-mode" data-widget="iframe" data-loading-screen="100">
    <div className="nav navbar navbar-expand navbar-white navbar-light border-bottom p-0">
        <li className="nav-item">
            <a className="nav-link" data-widget="pushmenu" href="#" role="button"><i className="fas fa-bars"></i></a>
        </li>
        <div className="nav-item dropdown">
            <a className="nav-link bg-danger dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Close</a>
            <div className="dropdown-menu mt-0">
                <a className="dropdown-item" href="#" data-widget="iframe-close" data-type="all">Close All</a>
                <a className="dropdown-item" href="#" data-widget="iframe-close" data-type="all-other">Close All Other</a>
            </div>
        </div>
        <a className="nav-link bg-light" href="#" data-widget="iframe-scrollleft"><i className="fas fa-angle-double-left"></i></a>
        <ul className="navbar-nav overflow-hidden" role="tablist"></ul>
        <a className="nav-link bg-light" href="#" data-widget="iframe-scrollright"><i className="fas fa-angle-double-right"></i></a>
        <a className="nav-link bg-light" href="#" data-widget="iframe-fullscreen"><i className="fas fa-expand"></i></a>
    </div>
    <div className="tab-content">
        <div className="tab-empty">
            <h4 className="display-4">No tab selected!</h4>
        </div>
        <div className="tab-loading">
            <div>
                <h4 className="display-4">Tab is loading <i className="fa fa-sync fa-spin"></i></h4>
            </div>
        </div>
    </div>
</div>
    <footer>
    <script src="/assets/js/jquery.js"></script>
          <script src="/assets/js/jquery-ui.min.js"></script>
          <script src="/assets/js/jquery.overlayScrollbars.js"></script>
    </footer>
    </>
    
  );
}